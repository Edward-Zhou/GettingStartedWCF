﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.ServiceModel.Description;
using System.ServiceModel.Dispatcher;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace WebClientWCFRequestConsumer
{
    class Program
    {
        static void Main(string[] args)
        {
            CallFromWebClient();
            Console.ReadLine();
        }

        public static void CallFromWebClient()
        {
            string endpoint = "http://localhost:59664/Service1.svc";
            string payload = System.IO.File.ReadAllText(@"D:\Sample\WCF\GettingStarted\WebClientWCFRequest\XML.xml");
            WebClient myWebClient = new WebClient();
            myWebClient.Headers.Add("Content-Type", "application/soap+xml; charset=utf-8");
           // myWebClient.Credentials = new ClientCredentials("","");
            //myWebClient.Headers.Add("Content-Type", "text/xml; charset=utf-8");
            //myWebClient.Headers.Add("SOAPAction", "\"http://tempuri.org/ICalculator/Add\"");
            var response = myWebClient.UploadString(endpoint, payload);
            Console.WriteLine(response);
            //byte[] byteArray = Encoding.ASCII.GetBytes(payload);
            //byte[] responseArray = myWebClient.UploadData(endpoint, "POST", byteArray);
            //Console.WriteLine("\nResponse received was {0}", Encoding.ASCII.GetString(responseArray));
            Console.ReadLine();
        }

        public static void CallFromWCF()
        {
            ServiceReference1.CalculatorClient client = new ServiceReference1.CalculatorClient();
            client.Endpoint.Behaviors.Add(new InspectorBehavior());
            double result= client.Add(1,2);

            Console.WriteLine(result.ToString());
        }
        public class MyMessageInspector : IClientMessageInspector
        {
            public void AfterReceiveReply(ref System.ServiceModel.Channels.Message reply, object correlationState)
            {
                //throw new NotImplementedException();
            }

            public object BeforeSendRequest(ref System.ServiceModel.Channels.Message request, System.ServiceModel.IClientChannel channel)
            {
                //throw new NotImplementedException();
                return null;
            }
        }
        public class InspectorBehavior : IEndpointBehavior
        {
            public void ApplyClientBehavior(ServiceEndpoint endpoint, ClientRuntime clientRuntime)
            {
                clientRuntime.MessageInspectors.Add(new MyMessageInspector());
            }

            public void AddBindingParameters(ServiceEndpoint endpoint, System.ServiceModel.Channels.BindingParameterCollection bindingParameters)
            {
                
            }

            public void ApplyDispatchBehavior(ServiceEndpoint endpoint, EndpointDispatcher endpointDispatcher)
            {
                
            }

            public void Validate(ServiceEndpoint endpoint)
            {
                
            }
        }
    }
}
